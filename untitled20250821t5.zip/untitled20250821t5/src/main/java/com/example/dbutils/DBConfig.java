package com.example.dbutils;

import java.io.*;
import java.util.Properties;

public class DBConfig {
    private static final String EXTERNAL_CONFIG_PATH = "./config/db.properties";
    private Properties properties;

    public DBConfig() {
        properties = new Properties();
        loadConfiguration();
    }

    private void loadConfiguration() {
        // 优先尝试从外部config目录加载
        File externalConfig = new File(EXTERNAL_CONFIG_PATH);
        if (externalConfig.exists()) {
            try (InputStream is = new FileInputStream(externalConfig)) {
                properties.load(is);
                return;
            } catch (IOException e) {
                System.err.println("外部配置文件加载失败，将尝试内部配置");
            }
        }

        // 外部配置不存在则从类路径加载
        try (InputStream is = getClass().getResourceAsStream("/db.properties")) {
            if (is != null) {
                properties.load(is);
            } else {
                throw new RuntimeException("未找到任何配置文件");
            }
        } catch (IOException e) {
            throw new RuntimeException("配置文件加载失败", e);
        }
    }

    public String getUrl() {
        return properties.getProperty("db.url");
    }

    public String getDatabaseName() {
        return properties.getProperty("db.name");
    }

    public String getUsername() {
        return properties.getProperty("db.username");
    }

    public String getEncryptedPassword() {
        return properties.getProperty("db.password");
    }
}
