package com.example.dbutils;

import java.sql.*;

public class DBConnection {
    public static void main(String[] args) {
        try {
            DBConfig config = new DBConfig();
            String password = AESUtil.decrypt(config.getEncryptedPassword());

            String connectionUrl = String.format("%s/%s?user=%s&password=%s",
                    config.getUrl(), config.getDatabaseName(),
                    config.getUsername(), password);

            try (Connection conn = DriverManager.getConnection(connectionUrl)) {
                System.out.println("成功连接到MySQL数据库!");

                Statement stmt = conn.createStatement();

                // 示例1：查询表结构信息
                String tableName = "user";
                queryTableStructure(conn, tableName);

                // 示例2：查询表数据
                ResultSet rs = queryTableData(stmt, tableName);

                // 新增功能：将查询结果写入newb表
                writeToNewbTable(conn, rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void queryTableStructure(Connection conn, String tableName) throws SQLException {
        DatabaseMetaData metaData = conn.getMetaData();
        try (ResultSet columns = metaData.getColumns(null, null, tableName, null)) {
            System.out.println("\n表结构信息 (" + tableName + "):");
            System.out.println("----------------------------------");
            System.out.printf("%-20s %-15s %-10s\n", "列名", "数据类型", "是否可为空");

            while (columns.next()) {
                String columnName = columns.getString("COLUMN_NAME");
                String dataType = columns.getString("TYPE_NAME");
                String nullable = columns.getString("IS_NULLABLE");
                System.out.printf("%-20s %-15s %-10s\n", columnName, dataType, nullable);
            }
        }
    }

    private static ResultSet queryTableData(Statement stmt, String tableName) throws SQLException {
        String query = "SELECT username FROM " + tableName + " LIMIT 10";
        ResultSet rs = stmt.executeQuery(query);

        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        System.out.println("\n表数据 (前10条):");
        System.out.println("----------------------------------");

        // 打印列名
        for (int i = 1; i <= columnCount; i++) {
            System.out.printf("%-20s", metaData.getColumnName(i));
        }
        System.out.println();

        // 打印数据
        while (rs.next()) {
            for (int i = 1; i <= columnCount; i++) {
                System.out.printf("%-20s", rs.getString(i));
            }
            System.out.println();
        }

        // 返回ResultSet以便后续处理
        rs.beforeFirst(); // 重置游标以便再次读取
        return rs;
    }

    private static void writeToNewbTable(Connection conn, ResultSet rs) throws SQLException {
        // 检查newb表是否存在
        DatabaseMetaData metaData = conn.getMetaData();
        ResultSet tables = metaData.getTables(null, null, "newb", null);

        if (!tables.next()) {
            // 表不存在，创建新表
            try (Statement stmt = conn.createStatement()) {
                String createTableSQL = "CREATE TABLE newb (username VARCHAR(255))";
                stmt.executeUpdate(createTableSQL);
                System.out.println("\n表newb创建成功!");
            }
        }
        tables.close();

        // 准备插入语句
        String insertSQL = "INSERT INTO newb (username) VALUES (?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            // 遍历结果集并插入数据
            int count = 0;
            while (rs.next()) {
                String username = rs.getString("username");
                pstmt.setString(1, username);
                pstmt.addBatch(); // 使用批处理提高性能
                count++;

                // 每100条执行一次批处理
                if (count % 100 == 0) {
                    pstmt.executeBatch();
                }
            }
            // 执行剩余的批处理
            pstmt.executeBatch();
            System.out.println("\n成功将" + count + "条username数据写入newb表!");
        }
    }
}
